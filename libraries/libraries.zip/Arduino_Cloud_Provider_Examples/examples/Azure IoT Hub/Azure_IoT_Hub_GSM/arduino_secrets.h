// GSM settings
#define SECRET_PINNUMBER     ""
#define SECRET_GPRS_APN      "GPRS_APN" // replace your GPRS APN
#define SECRET_GPRS_LOGIN    "login"    // replace with your GPRS login
#define SECRET_GPRS_PASSWORD "password" // replace with your GPRS password

// Fill in the hostname of your Azure IoT Hub broker
#define SECRET_BROKER    "<hub name>.azure-devices.net"

// Fill in the device id
#define SECRET_DEVICE_ID "<device id>"
